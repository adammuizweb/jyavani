<?php
declare(strict_types=1);

if (!defined('DASHBOARD_CONTEXT')) exit;

$pdo = $GLOBALS['pdo'];

// ——— Schema ———
try {
    $pdo->query("SELECT 1 FROM `jetmax_traffic` LIMIT 1");
} catch (\Throwable $e) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `jetmax_traffic` (
        `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        `post_id` bigint(20) unsigned DEFAULT NULL,
        `post_type` varchar(20) DEFAULT NULL,
        `is_404` tinyint(1) NOT NULL DEFAULT 0,
        `url` varchar(2048) NOT NULL DEFAULT '',
        `ip_address` varchar(64) NOT NULL DEFAULT '',
        `user_agent` text DEFAULT NULL,
        `referrer` text DEFAULT NULL,
        `search_query` varchar(255) DEFAULT NULL,
        `country_code` char(2) DEFAULT NULL,
        `country_name` varchar(128) DEFAULT NULL,
        `visited_at` datetime NOT NULL DEFAULT current_timestamp(),
        PRIMARY KEY (`id`),
        KEY `visited_at` (`visited_at`),
        KEY `post_id` (`post_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS `jetmax_ip_cache` (
        `ip_address` varchar(64) NOT NULL PRIMARY KEY,
        `country_code` char(2) DEFAULT NULL,
        `country_name` varchar(128) DEFAULT NULL,
        `updated_at` datetime NOT NULL DEFAULT current_timestamp()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

// Migration: ip_hash → ip_address
try {
    $pdo->query("SELECT `ip_hash` FROM `jetmax_traffic` LIMIT 1");
    $pdo->exec("ALTER TABLE `jetmax_traffic` CHANGE COLUMN `ip_hash` `ip_address` VARCHAR(64) NOT NULL DEFAULT ''");
} catch (\Throwable $e) {}
try {
    $pdo->query("SELECT `ip_hash` FROM `jetmax_ip_cache` LIMIT 1");
    $pdo->exec("ALTER TABLE `jetmax_ip_cache` CHANGE COLUMN `ip_hash` `ip_address` VARCHAR(64) NOT NULL");
} catch (\Throwable $e) {}

// Migration: search_query, is_404
try {
    $pdo->query("SELECT `search_query` FROM `jetmax_traffic` LIMIT 1");
} catch (\Throwable $e) {
    @$pdo->exec("ALTER TABLE `jetmax_traffic` ADD COLUMN `search_query` varchar(255) DEFAULT NULL AFTER `referrer`");
}
try {
    $pdo->query("SELECT `is_404` FROM `jetmax_traffic` LIMIT 1");
} catch (\Throwable $e) {
    @$pdo->exec("ALTER TABLE `jetmax_traffic` ADD COLUMN `is_404` tinyint(1) NOT NULL DEFAULT 0 AFTER `post_type`");
}

$base = defined('ADMIN_BASE_PATH') ? ADMIN_BASE_PATH : '/adiwira';

// ——— Dashboard widget toggle ———
$dashEnabled = settings_get($pdo, 'jetmax_dash_widget_enabled', '0');
if (isset($_GET['jetmax_toggle_dash'])) {
    $new = $dashEnabled === '1' ? '0' : '1';
    settings_set($pdo, 'jetmax_dash_widget_enabled', $new);
    $layoutJson = settings_get($pdo, 'dashboard_widget_layout', '');
    $layout = $layoutJson ? json_decode($layoutJson, true) : [];
    if ($new === '1') {
        $found = false;
        foreach ($layout as $item) {
            if (is_string($item) && str_starts_with($item, 'jetmax_traffic')) { $found = true; break; }
        }
        if (!$found) {
            $layout[] = 'jetmax_traffic:l';
            settings_set($pdo, 'dashboard_widget_layout', json_encode($layout));
        }
    } else {
        $filtered = array_values(array_filter($layout, fn($item) => !is_string($item) || !str_starts_with($item, 'jetmax_traffic')));
        if (count($filtered) !== count($layout)) {
            settings_set($pdo, 'dashboard_widget_layout', json_encode($filtered));
        }
    }
    $url = '?' . http_build_query(array_diff_key($_GET, ['jetmax_toggle_dash' => 1]));
    if (!headers_sent()) {
        header('Location: ' . $url);
        exit;
    }
    echo '<!doctype html><html><head><meta charset="utf-8"><script>window.location.href=' . json_encode($url) . ';</script><noscript><meta http-equiv="refresh" content="0;url=' . e($url) . '"></noscript></head><body></body></html>';
    exit;
}

// ——— Sidebar widget toggle ———
$sidebarEnabled = settings_get($pdo, 'jetmax_sidebar_widget_enabled', '0');
if (isset($_GET['jetmax_toggle_sidebar'])) {
    $new = $sidebarEnabled === '1' ? '0' : '1';
    settings_set($pdo, 'jetmax_sidebar_widget_enabled', $new);
    $url = '?' . http_build_query(array_diff_key($_GET, ['jetmax_toggle_sidebar' => 1]));
    if (!headers_sent()) {
        header('Location: ' . $url);
        exit;
    }
    echo '<!doctype html><html><head><meta charset="utf-8"><script>window.location.href=' . json_encode($url) . ';</script><noscript><meta http-equiv="refresh" content="0;url=' . e($url) . '"></noscript></head><body></body></html>';
    exit;
}

// ——— Date range ———
$range = $_GET['range'] ?? '7d';
$ranges = [
    '24h'  => ['label' => '24 Hours', 'sql' => 'INTERVAL 24 HOUR'],
    '7d'   => ['label' => '7 Days',   'sql' => 'INTERVAL 7 DAY'],
    '30d'  => ['label' => '30 Days',  'sql' => 'INTERVAL 30 DAY'],
    '3m'   => ['label' => '3 Months', 'sql' => 'INTERVAL 3 MONTH'],
    '6m'   => ['label' => '6 Months', 'sql' => 'INTERVAL 6 MONTH'],
    '1y'   => ['label' => '1 Year',   'sql' => 'INTERVAL 1 YEAR'],
    'all'  => ['label' => 'All Time', 'sql' => 'INTERVAL 100 YEAR'],
];
if (!isset($ranges[$range])) $range = '7d';
$intervalSql = $ranges[$range]['sql'];

$chartGroup = ($range === '24h') ? "DATE_FORMAT(`visited_at`, '%Y-%m-%d %H:00')" : "DATE(`visited_at`)";
$chartLabel = ($range === '24h') ? 'Hour' : 'Date';

// ——— Period filter (dari klik bar) ———
$period = $_GET['period'] ?? '';
$periodWhere = '';
$periodBind = [];
if ($period !== '') {
    $periodWhere = " AND $chartGroup = ?";
    $periodBind[] = $period;
}

// ——— Pagination ———
$perPage = 25;
$activeTab = $_GET['tab'] ?? 'pages';
if (!in_array($activeTab, ['pages','articles','referrers','countries','searches','recent','categories'], true)) $activeTab = 'pages';
$page = max(1, (int)($_GET['p'] ?? 1));
$offset = ($page - 1) * $perPage;

// ——— Build base WHERE ———
$whereBase = "`visited_at` >= NOW() - $intervalSql$periodWhere";

// ——— Summary ———
$summary = $pdo->prepare("SELECT
    COUNT(*) AS total,
    COUNT(DISTINCT `ip_address`) AS unique_visitors,
    SUM(CASE WHEN DATE(`visited_at`) = CURDATE() THEN 1 ELSE 0 END) AS today,
    SUM(CASE WHEN `post_id` IS NOT NULL THEN 1 ELSE 0 END) AS post_views,
    SUM(`is_404`) AS total_404,
    SUM(CASE WHEN `search_query` IS NOT NULL AND `search_query` != '' THEN 1 ELSE 0 END) AS total_searches
FROM `jetmax_traffic` WHERE $whereBase");
$summary->execute($periodBind);
$s = $summary->fetch(PDO::FETCH_ASSOC);

// ——— Chart data (ignore period filter — always show full range) ———
$chart = $pdo->prepare("SELECT $chartGroup AS period, COUNT(*) AS hits, COUNT(DISTINCT `ip_address`) AS uniques
    FROM `jetmax_traffic` WHERE `visited_at` >= NOW() - $intervalSql GROUP BY period ORDER BY period ASC");
$chart->execute();
$chartRows = $chart->fetchAll(PDO::FETCH_ASSOC);

$maxHits = 1;
foreach ($chartRows as $r) {
    if ((int)$r['hits'] > $maxHits) $maxHits = (int)$r['hits'];
}

// ——— Helper: paginated query ———
function fetch_tab(PDO $pdo, string $countSql, string $dataSql, array $bind, int $perPage, int $offset): array {
    $total = $pdo->prepare($countSql);
    $total->execute($bind);
    $totalCount = (int)$total->fetchColumn();

    $data = $pdo->prepare("$dataSql LIMIT $perPage OFFSET $offset");
    $data->execute($bind);
    $rows = $data->fetchAll(PDO::FETCH_ASSOC);

    return ['total' => $totalCount, 'rows' => $rows];
}

$tabs = [];

// Pages
$tabs['pages'] = fetch_tab($pdo,
    "SELECT COUNT(DISTINCT `url`) FROM `jetmax_traffic` WHERE $whereBase",
    "SELECT `url`, COUNT(*) AS hits FROM `jetmax_traffic` WHERE $whereBase GROUP BY `url` ORDER BY hits DESC",
    $periodBind, $perPage, $offset
);

// Articles
$tabs['articles'] = fetch_tab($pdo,
    "SELECT COUNT(DISTINCT t.`post_id`) FROM `jetmax_traffic` t WHERE t.`post_id` IS NOT NULL AND $whereBase",
    "SELECT t.`post_id`, p.`title`, p.`slug`, p.`type`, COUNT(*) AS hits
     FROM `jetmax_traffic` t LEFT JOIN `posts` p ON t.`post_id` = p.`id`
     WHERE t.`post_id` IS NOT NULL AND $whereBase
     GROUP BY t.`post_id` ORDER BY hits DESC",
    $periodBind, $perPage, $offset
);

// Referrers
$tabs['referrers'] = fetch_tab($pdo,
    "SELECT COUNT(DISTINCT `referrer`) FROM `jetmax_traffic` WHERE `referrer` != '' AND $whereBase",
    "SELECT `referrer`, COUNT(*) AS hits FROM `jetmax_traffic` WHERE `referrer` != '' AND $whereBase GROUP BY `referrer` ORDER BY hits DESC",
    $periodBind, $perPage, $offset
);

// Countries
$tabs['countries'] = fetch_tab($pdo,
    "SELECT COUNT(DISTINCT `country_code`) FROM `jetmax_traffic` WHERE `country_code` IS NOT NULL AND $whereBase",
    "SELECT `country_code`, `country_name`, COUNT(*) AS hits, COUNT(DISTINCT `ip_address`) AS uniques
     FROM `jetmax_traffic` WHERE `country_code` IS NOT NULL AND $whereBase
     GROUP BY `country_code` ORDER BY hits DESC",
    $periodBind, $perPage, $offset
);

// Categories
$tabs['categories'] = fetch_tab($pdo,
    "SELECT COUNT(DISTINCT c.id)
     FROM `jetmax_traffic` t
     JOIN `post_categories` pc ON pc.post_id = t.post_id
     JOIN `categories` c ON c.id = pc.category_id
     WHERE t.post_id IS NOT NULL AND $whereBase",
    "SELECT c.name, c.slug, COUNT(*) AS hits, COUNT(DISTINCT t.`ip_address`) AS uniques
     FROM `jetmax_traffic` t
     JOIN `post_categories` pc ON pc.post_id = t.post_id
     JOIN `categories` c ON c.id = pc.category_id
     WHERE t.post_id IS NOT NULL AND $whereBase
     GROUP BY c.id ORDER BY hits DESC",
    $periodBind, $perPage, $offset
);

// Recent
$tabs['recent'] = fetch_tab($pdo,
    "SELECT COUNT(*) FROM `jetmax_traffic` WHERE $whereBase",
    "SELECT `url`, `ip_address`, `user_agent`, `country_code`, `search_query`, `visited_at`, `post_id`, `is_404`
     FROM `jetmax_traffic` WHERE $whereBase ORDER BY `visited_at` DESC",
    $periodBind, $perPage, $offset
);

// Searches
$tabs['searches'] = fetch_tab($pdo,
    "SELECT COUNT(DISTINCT `search_query`) FROM `jetmax_traffic` WHERE `search_query` IS NOT NULL AND `search_query` != '' AND $whereBase",
    "SELECT `search_query`, COUNT(*) AS hits, MAX(`visited_at`) AS last_seen
     FROM `jetmax_traffic` WHERE `search_query` IS NOT NULL AND `search_query` != '' AND $whereBase
     GROUP BY `search_query` ORDER BY hits DESC",
    $periodBind, $perPage, $offset
);

$totalPages = max(1, (int)ceil(($tabs[$activeTab]['total'] ?? 0) / $perPage));
if ($page > $totalPages) $page = $totalPages;
if ($page < 1) $page = 1;

function url(array $extra = []): string {
    $params = ['page' => 'admin/tools/jetmax', 'range' => $GLOBALS['range']];
    if ($GLOBALS['period'] !== '') $params['period'] = $GLOBALS['period'];
    $params['tab'] = $GLOBALS['activeTab'];
    foreach ($extra as $k => $v) $params[$k] = $v;
    return '?' . http_build_query($params);
}
$buildUrl = 'url';
?>
<style>
.jm-chart-wrap { overflow-x:auto; padding-top:8px }
.jm-chart { display:flex; align-items:flex-end; gap:3px; height:160px; min-width:100% }
.jm-bar-wrap { flex:1; display:flex; flex-direction:column; align-items:center; height:100%; justify-content:flex-end; position:relative }
.jm-bar { width:100%; min-width:4px; border-radius:3px 3px 0 0; transition:opacity .2s; cursor:pointer; background:var(--adam-primary) }
.jm-bar:hover { opacity:.7 }
.jm-bar.active { outline:2px solid var(--adam-text); outline-offset:-2px }
.jm-bar.unique { background:var(--adam-muted); height:0 }
.jm-bar-label { font-size:9px; color:var(--adam-muted); margin-top:4px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:50px; text-align:center }
.jm-range-form { display:flex; gap:6px; flex-wrap:wrap; margin-bottom:20px }
.jm-range-btn { padding:6px 14px; border-radius:6px; border:1px solid var(--adam-border); background:var(--adam-card); color:var(--adam-text); font-size:12px; cursor:pointer; text-decoration:none; transition:all .15s }
.jm-range-btn:hover { border-color:var(--adam-primary); color:var(--adam-primary) }
.jm-range-btn.active { background:var(--adam-primary); color:#fff; border-color:var(--adam-primary) }
.jm-grid2 { display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:16px }
.jm-grid3 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px; margin-bottom:16px }
.jm-card { background:var(--adam-card); border:1px solid var(--adam-border); border-radius:var(--adam-radius-lg); padding:20px; box-shadow:var(--adam-shadow) }
.jm-card h3 { margin:0 0 12px; font-size:11px; text-transform:uppercase; letter-spacing:.6px; opacity:.6; color:var(--adam-text) }
.jm-stat { display:flex; gap:16px; flex-wrap:wrap }
.jm-stat-item { flex:1; min-width:100px }
.jm-stat-item .num { font-size:28px; font-weight:700; color:var(--adam-text); margin:0; line-height:1.2 }
.jm-stat-item .lbl { font-size:11px; text-transform:uppercase; letter-spacing:.5px; opacity:.5; color:var(--adam-text); margin-top:2px }
.jm-table { width:100%; border-collapse:collapse }
.jm-table th { text-align:left; padding:8px 10px; font-size:11px; text-transform:uppercase; letter-spacing:.4px; opacity:.5; color:var(--adam-text); border-bottom:1px solid var(--adam-border); font-weight:600 }
.jm-table td { padding:8px 10px; border-bottom:1px solid var(--adam-border-soft); font-size:13px; color:var(--adam-text) }
.jm-table tr:hover td { background:var(--adam-hover) }
.jm-link { color:var(--adam-link); text-decoration:none }
.jm-link:hover { color:var(--adam-link-hover); text-decoration:underline }
.jm-flag { display:inline-block; width:20px; height:14px; vertical-align:middle; margin-right:6px; border-radius:2px }
.jm-badge { display:inline-block; padding:2px 8px; border-radius:4px; font-size:11px; font-weight:600; background:var(--adam-surface-3); color:var(--adam-text-2) }
.jm-tabs { display:flex; gap:0; border-bottom:1px solid var(--adam-border); margin-bottom:16px; flex-wrap:wrap }
.jm-tab { padding:10px 18px; font-size:12px; font-weight:600; cursor:pointer; border-bottom:2px solid transparent; color:var(--adam-muted); transition:all .15s; background:none; border-top:none; border-left:none; border-right:none }
.jm-tab:hover { color:var(--adam-text); border-bottom-color:var(--adam-border) }
.jm-tab.active { color:var(--adam-primary); border-bottom-color:var(--adam-primary) }
.jm-tab-count { font-weight:400; opacity:.6; margin-left:4px }
.jm-pager { display:flex; gap:4px; align-items:center; justify-content:center; margin-top:12px; flex-wrap:wrap }
.jm-pager a, .jm-pager span { padding:5px 10px; font-size:12px; border-radius:4px; text-decoration:none; color:var(--adam-text); background:var(--adam-card); border:1px solid var(--adam-border) }
.jm-pager a:hover { border-color:var(--adam-primary); color:var(--adam-primary) }
.jm-pager .current { background:var(--adam-primary); color:#fff; border-color:var(--adam-primary) }
.jm-pager .disabled { opacity:.3; pointer-events:none }
.jm-clear-period { font-size:11px; margin-left:8px; padding:2px 8px; border-radius:4px; text-decoration:none; background:var(--adam-surface-3); color:var(--adam-muted) }
.jm-clear-period:hover { color:var(--adam-text) }
.jm-modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,.5); z-index:9999; display:none; align-items:center; justify-content:center }
.jm-modal { background:var(--adam-card); border-radius:12px; max-width:480px; width:90%; max-height:80vh; overflow-y:auto; box-shadow:0 20px 60px rgba(0,0,0,.3) }
.jm-modal-header { display:flex; align-items:center; justify-content:space-between; padding:16px 20px; border-bottom:1px solid var(--adam-border) }
.jm-modal-header h3 { margin:0; font-size:15px; color:var(--adam-text) }
.jm-modal-close { background:none; border:none; font-size:22px; cursor:pointer; color:var(--adam-muted); padding:0; line-height:1 }
.jm-modal-close:hover { color:var(--adam-text) }
.jm-modal-body { padding:20px }
.jm-modal-section { margin-bottom:20px }
.jm-modal-section:last-child { margin-bottom:0 }
.jm-modal-section h4 { font-size:12px; text-transform:uppercase; letter-spacing:.5px; opacity:.5; color:var(--adam-text); margin:0 0 12px }
.jm-modal-info { font-size:13px; color:var(--adam-text); line-height:1.6 }
.jm-modal-info tr td:first-child { opacity:.6; padding-right:12px; white-space:nowrap }
.jm-modal-info tr td { padding:2px 0 }
.jm-toggle-wrap { display:flex; align-items:center; gap:12px }
.jm-toggle { display:inline-flex; align-items:center; gap:8px; padding:8px 16px; border-radius:6px; border:1px solid var(--adam-border); background:var(--adam-surface-3); color:var(--adam-text); text-decoration:none; font-size:13px; cursor:pointer; transition:all .15s }
.jm-toggle:hover { border-color:var(--adam-primary) }
.jm-toggle.on { background:var(--adam-primary); color:#fff; border-color:var(--adam-primary) }
.jm-toggle.off { opacity:.6 }
</style>

<form method="get" class="jm-range-form" id="jm-range-form">
    <input type="hidden" name="page" value="admin/tools/jetmax">
    <a href="#" class="jm-range-btn" id="jm-settings-btn" onclick="document.getElementById('jm-modal').style.display='flex';return false">⚙ Settings</a>
    <?php foreach ($ranges as $k => $v): ?>
    <a href="<?= $buildUrl(['range' => $k, 'p' => 1]) ?>" class="jm-range-btn <?= $range === $k ? 'active' : '' ?>"><?= $v['label'] ?></a>
    <?php endforeach; ?>
    <span style="flex:1"></span>
    <span style="font-size:11px;color:var(--adam-muted);align-self:center">
        <?= (int)$s['total'] ?> views
        <?php if ($period !== ''): ?>
        &middot; <strong><?= e($period) ?></strong>
        <a href="<?= $buildUrl(['period' => null, 'p' => 1]) ?>" class="jm-clear-period">clear filter</a>
        <?php endif; ?>
    </span>
</form>

<div class="jm-grid3">
    <div class="jm-card">
        <h3>Page Views</h3>
        <div class="num" style="font-size:32px;font-weight:700;color:var(--adam-text)"><?= (int)$s['total'] ?></div>
        <div style="font-size:12px;color:var(--adam-muted);margin-top:2px"><?= (int)$s['today'] ?> today</div>
    </div>
    <div class="jm-card">
        <h3>Unique Visitors</h3>
        <div class="num" style="font-size:32px;font-weight:700;color:var(--adam-text)"><?= (int)$s['unique_visitors'] ?></div>
        <div style="font-size:12px;color:var(--adam-muted);margin-top:2px"><?= (int)$s['post_views'] ?> article views</div>
    </div>
    <div class="jm-card">
        <h3>Errors &amp; Searches</h3>
        <div style="display:flex;gap:20px;flex-wrap:wrap">
            <div>
                <div class="num" style="font-size:28px;font-weight:700;color:var(--adam-text);margin:0;line-height:1.2"><?= (int)$s['total_404'] ?></div>
                <div style="font-size:11px;text-transform:uppercase;letter-spacing:.5px;opacity:.5;color:var(--adam-text);margin-top:2px">404</div>
            </div>
            <div>
                <div class="num" style="font-size:28px;font-weight:700;color:var(--adam-text);margin:0;line-height:1.2"><?= (int)$s['total_searches'] ?></div>
                <div style="font-size:11px;text-transform:uppercase;letter-spacing:.5px;opacity:.5;color:var(--adam-text);margin-top:2px">Searches</div>
            </div>
            <div>
                <div class="num" style="font-size:28px;font-weight:700;color:var(--adam-text);margin:0;line-height:1.2"><?= (int)$tabs['countries']['total'] ?></div>
                <div style="font-size:11px;text-transform:uppercase;letter-spacing:.5px;opacity:.5;color:var(--adam-text);margin-top:2px">Countries</div>
            </div>
        </div>
    </div>
</div>

<?php if (!empty($chartRows)): ?>
<div class="jm-card" style="margin-bottom:16px">
    <h3>Traffic — <?= $ranges[$range]['label'] ?></h3>
    <div style="display:flex;gap:16px;font-size:11px;color:var(--adam-muted);margin-bottom:4px">
        <span><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:var(--adam-primary);vertical-align:middle;margin-right:4px"></span> Views</span>
        <span><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:var(--adam-muted);vertical-align:middle;margin-right:4px"></span> Unique</span>
    </div>
    <div class="jm-chart-wrap">
        <div class="jm-chart" style="height:160px">
            <?php foreach ($chartRows as $i => $r):
                $h = max(1, (int)$r['hits']);
                $u = max(1, (int)$r['uniques']);
                $hp = round(($h / $maxHits) * 100);
                $up = round(($u / $maxHits) * 100);
                $isActive = ($period === $r['period']);
            ?>
            <div class="jm-bar-wrap" title="<?= e($r['period']) ?> — <?= $h ?> views, <?= $u ?> unique">
                <a href="<?= $buildUrl(['period' => $r['period'], 'p' => 1]) ?>" class="jm-bar <?= $isActive ? 'active' : '' ?>" style="height:<?= $hp ?>%;background:var(--adam-primary);display:block"></a>
                <div class="jm-bar unique" style="height:<?= $up ?>%;background:var(--adam-muted);margin-top:-<?= $up ?>px;opacity:.5"></div>
                <div class="jm-bar-label"><?= $chartLabel === 'Hour' ? date('H:00', strtotime($r['period'])) : date('M j', strtotime($r['period'])) ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="jm-card" style="margin-bottom:16px">
    <div class="jm-tabs">
        <button class="jm-tab <?= $activeTab === 'pages' ? 'active' : '' ?>" data-tab="pages">Pages <span class="jm-tab-count"><?= (int)$tabs['pages']['total'] ?></span></button>
        <button class="jm-tab <?= $activeTab === 'articles' ? 'active' : '' ?>" data-tab="articles">Articles <span class="jm-tab-count"><?= (int)$tabs['articles']['total'] ?></span></button>
        <button class="jm-tab <?= $activeTab === 'referrers' ? 'active' : '' ?>" data-tab="referrers">Referrers <span class="jm-tab-count"><?= (int)$tabs['referrers']['total'] ?></span></button>
        <button class="jm-tab <?= $activeTab === 'countries' ? 'active' : '' ?>" data-tab="countries">Countries <span class="jm-tab-count"><?= (int)$tabs['countries']['total'] ?></span></button>
        <button class="jm-tab <?= $activeTab === 'categories' ? 'active' : '' ?>" data-tab="categories">Categories <span class="jm-tab-count"><?= (int)$tabs['categories']['total'] ?></span></button>
        <button class="jm-tab <?= $activeTab === 'searches' ? 'active' : '' ?>" data-tab="searches">Searches <span class="jm-tab-count"><?= (int)$tabs['searches']['total'] ?></span></button>
        <button class="jm-tab <?= $activeTab === 'recent' ? 'active' : '' ?>" data-tab="recent">Recent <span class="jm-tab-count"><?= (int)$tabs['recent']['total'] ?></span></button>
    </div>

    <?php $tabData = $tabs[$activeTab]['rows'] ?? []; ?>
    <?php if (empty($tabData)): ?>
    <p style="opacity:.5;color:var(--adam-muted);text-align:center;padding:20px 0">No data<?= $period !== '' ? ' for this period' : ' yet' ?></p>
    <?php else: ?>

    <?php if ($activeTab === 'pages'): ?>
    <table class="jm-table">
        <tr><th>Page</th><th style="width:80px;text-align:right">Views</th></tr>
        <?php foreach ($tabData as $r): ?>
        <tr>
            <td><a href="<?= e($r['url']) ?>" target="_blank" class="jm-link" style="max-width:500px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:inline-block;vertical-align:middle"><?= e($r['url']) ?></a></td>
            <td style="text-align:right;font-weight:600"><?= $r['hits'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <?php elseif ($activeTab === 'articles'): ?>
    <table class="jm-table">
        <tr><th>Article</th><th style="width:80px;text-align:right">Views</th></tr>
        <?php foreach ($tabData as $r): ?>
        <tr>
            <td style="max-width:500px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                <?php if ($r['slug']): ?>
                <a href="/<?= e($r['slug']) ?>/" target="_blank" class="jm-link"><?= e($r['title'] ?: $r['slug']) ?></a>
                <?php else: ?>
                <span style="opacity:.5;color:var(--adam-muted)">post #<?= $r['post_id'] ?></span>
                <?php endif; ?>
            </td>
            <td style="text-align:right;font-weight:600"><?= $r['hits'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <?php elseif ($activeTab === 'referrers'): ?>
    <table class="jm-table">
        <tr><th>Source</th><th style="width:80px;text-align:right">Views</th></tr>
        <?php foreach ($tabData as $r): ?>
        <tr>
            <td style="max-width:500px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                <?php if (str_starts_with($r['referrer'], 'http')): ?>
                <a href="<?= e($r['referrer']) ?>" target="_blank" rel="noopener" class="jm-link"><?= e(parse_url($r['referrer'], PHP_URL_HOST) ?: $r['referrer']) ?></a>
                <?php else: ?>
                <span style="opacity:.5;color:var(--adam-muted)">direct / unknown</span>
                <?php endif; ?>
            </td>
            <td style="text-align:right;font-weight:600"><?= $r['hits'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <?php elseif ($activeTab === 'countries'): ?>
    <table class="jm-table">
        <tr><th>Country</th><th style="width:80px;text-align:right">Visits</th><th style="width:80px;text-align:right">Unique</th></tr>
        <?php foreach ($tabData as $r): ?>
        <tr>
            <td>
                <?php if ($r['country_code']): ?>
                <span class="jm-flag" style="background:var(--adam-surface-3);text-align:center;line-height:14px;font-size:10px"><?= e($r['country_code']) ?></span>
                <?php endif; ?>
                <?= e($r['country_name'] ?? $r['country_code'] ?? 'Unknown') ?>
            </td>
            <td style="text-align:right;font-weight:600"><?= $r['hits'] ?></td>
            <td style="text-align:right;color:var(--adam-muted)"><?= $r['uniques'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <?php elseif ($activeTab === 'categories'): ?>
    <table class="jm-table">
        <tr><th>Category</th><th style="width:80px;text-align:right">Visits</th><th style="width:80px;text-align:right">Unique</th></tr>
        <?php foreach ($tabData as $r): ?>
        <tr>
            <td>
                <a href="/category/<?= e($r['slug']) ?>/" target="_blank" class="jm-link"><?= e($r['name'] ?: $r['slug']) ?></a>
            </td>
            <td style="text-align:right;font-weight:600"><?= $r['hits'] ?></td>
            <td style="text-align:right;color:var(--adam-muted)"><?= $r['uniques'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <?php elseif ($activeTab === 'searches'): ?>
    <table class="jm-table">
        <tr><th>Search Query</th><th style="width:80px;text-align:right">Times</th><th style="width:140px">Last Seen</th></tr>
        <?php foreach ($tabData as $r): ?>
        <tr>
            <td><?= e($r['search_query']) ?></td>
            <td style="text-align:right;font-weight:600"><?= $r['hits'] ?></td>
            <td style="white-space:nowrap;color:var(--adam-muted);font-size:12px"><?= date('M j, H:i', strtotime($r['last_seen'])) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <?php elseif ($activeTab === 'recent'): ?>
    <table class="jm-table">
        <tr><th>Page</th><th style="width:50px">404</th><th style="width:70px">Country</th><th style="width:130px">IP</th><th style="width:130px">Time</th></tr>
        <?php foreach ($tabData as $r): ?>
        <tr>
            <td style="max-width:350px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                <a href="<?= e($r['url']) ?>" target="_blank" class="jm-link"><?= e($r['url']) ?></a>
                <?php if (!empty($r['search_query'])): ?>
                <span style="font-size:10px;color:var(--adam-muted);margin-left:4px">?s=<?= e($r['search_query']) ?></span>
                <?php endif; ?>
            </td>
            <td style="text-align:center">
                <?php if (!empty($r['is_404'])): ?>
                <span class="jm-badge" style="background:#d32f2f;color:#fff">404</span>
                <?php else: ?>
                <span style="opacity:.2">—</span>
                <?php endif; ?>
            </td>
            <td>
                <?php if ($r['country_code']): ?>
                <span class="jm-badge"><?= e($r['country_code']) ?></span>
                <?php else: ?>
                <span style="opacity:.3">—</span>
                <?php endif; ?>
            </td>
            <td style="white-space:nowrap;color:var(--adam-muted);font-size:11px;font-family:monospace"><?= e($r['ip_address']) ?></td>
            <td style="white-space:nowrap;color:var(--adam-muted);font-size:12px"><?= date('M j, H:i', strtotime($r['visited_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <?php endif; ?>

    <?php if ($totalPages > 1): ?>
    <div class="jm-pager">
        <?php if ($page > 1): ?>
        <a href="<?= $buildUrl(['p' => $page - 1]) ?>">&laquo; Prev</a>
        <?php else: ?>
        <span class="disabled">&laquo; Prev</span>
        <?php endif; ?>

        <?php
        $start = max(1, $page - 2);
        $end = min($totalPages, $page + 2);
        if ($start > 1): ?>
        <a href="<?= $buildUrl(['p' => 1]) ?>">1</a>
        <?php if ($start > 2): ?><span style="opacity:.3">…</span><?php endif; ?>
        <?php endif; ?>

        <?php for ($i = $start; $i <= $end; $i++): ?>
        <?php if ($i === $page): ?>
        <span class="current"><?= $i ?></span>
        <?php else: ?>
        <a href="<?= $buildUrl(['p' => $i]) ?>"><?= $i ?></a>
        <?php endif; ?>
        <?php endfor; ?>

        <?php if ($end < $totalPages): ?>
        <?php if ($end < $totalPages - 1): ?><span style="opacity:.3">…</span><?php endif; ?>
        <a href="<?= $buildUrl(['p' => $totalPages]) ?>"><?= $totalPages ?></a>
        <?php endif; ?>

        <?php if ($page < $totalPages): ?>
        <a href="<?= $buildUrl(['p' => $page + 1]) ?>">Next &raquo;</a>
        <?php else: ?>
        <span class="disabled">Next &raquo;</span>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

<p style="opacity:.3;font-size:11px;color:var(--adam-muted)">JetMax v1.1.0 — Geolokasi via ip-api.com (free tier).</p>

<div class="jm-modal-overlay" id="jm-modal" onclick="if(event.target===this)this.style.display='none'">
  <div class="jm-modal">
    <div class="jm-modal-header">
      <h3>⚙ JetMax Settings</h3>
      <button class="jm-modal-close" onclick="document.getElementById('jm-modal').style.display='none'">&times;</button>
    </div>
    <div class="jm-modal-body">
      <div class="jm-modal-section">
        <h4>Dashboard Widget</h4>
        <div class="jm-toggle-wrap">
          <a href="<?= $buildUrl(['jetmax_toggle_dash' => 1]) ?>" class="jm-toggle <?= $dashEnabled === '1' ? 'on' : 'off' ?>">
            <?= $dashEnabled === '1' ? '🟢 Enabled' : '⭕ Disabled' ?>
          </a>
          <span style="font-size:12px;color:var(--adam-muted)">Show traffic snippet on dashboard home</span>
        </div>
      </div>
      <div class="jm-modal-section">
        <h4>Public Sidebar Widget</h4>
        <div class="jm-toggle-wrap">
          <a href="<?= $buildUrl(['jetmax_toggle_sidebar' => 1]) ?>" class="jm-toggle <?= $sidebarEnabled === '1' ? 'on' : 'off' ?>">
            <?= $sidebarEnabled === '1' ? '🟢 Enabled' : '⭕ Disabled' ?>
          </a>
          <span style="font-size:12px;color:var(--adam-muted)">Show traffic widget in sidebar zones (admin → Sidebar)</span>
        </div>
      </div>
      <div class="jm-modal-section">
        <h4>Plugin Info</h4>
        <table class="jm-modal-info">
          <tr><td>Name</td><td><strong>JetMax — Traffic Analytics</strong></td></tr>
          <tr><td>Version</td><td>1.1.0</td></tr>
          <tr><td>Author</td><td>Adam Muiz</td></tr>
          <tr><td>Description</td><td>Track page views, visitor analytics, and traffic stats for your Jyavani CMS site.</td></tr>
          <tr><td>Data</td><td>Geolokasi via ip-api.com (free tier).</td></tr>
        </table>
      </div>
    </div>
  </div>
</div>

<script>
(function() {
    document.querySelectorAll('.jm-tab').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var tab = this.getAttribute('data-tab');
            var url = new URL(window.location.href);
            url.searchParams.set('tab', tab);
            url.searchParams.set('p', '1');
            window.location.href = url.toString();
        });
    });
})();
</script>
