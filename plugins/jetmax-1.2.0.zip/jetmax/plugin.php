<?php
declare(strict_types=1);

function jetmax_ensure_schema(): void {
    $pdo = $GLOBALS['pdo'] ?? null;
    if (!$pdo) return;

    try {
        $pdo->query("SELECT 1 FROM `jetmax_traffic` LIMIT 1");
    } catch (\Throwable $e) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS `jetmax_traffic` (
            `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            `post_id` bigint(20) unsigned DEFAULT NULL,
            `post_type` varchar(20) DEFAULT NULL,
            `is_404` tinyint(1) NOT NULL DEFAULT 0,
            `url` varchar(2048) NOT NULL DEFAULT '',
            `ip_address` varchar(64) NOT NULL DEFAULT '',
            `user_agent` text DEFAULT NULL,
            `referrer` text DEFAULT NULL,
            `search_query` varchar(255) DEFAULT NULL,
            `country_code` char(2) DEFAULT NULL,
            `country_name` varchar(128) DEFAULT NULL,
            `visited_at` datetime NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`),
            KEY `visited_at` (`visited_at`),
            KEY `post_id` (`post_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }

    // Migration: ip_hash → ip_address
    try {
        $pdo->query("SELECT `ip_hash` FROM `jetmax_traffic` LIMIT 1");
        $pdo->exec("ALTER TABLE `jetmax_traffic` CHANGE COLUMN `ip_hash` `ip_address` VARCHAR(64) NOT NULL DEFAULT ''");
    } catch (\Throwable $e) {
        // ip_hash column doesn't exist — already migrated or new table
    }

    try {
        $pdo->query("SELECT `country_code` FROM `jetmax_traffic` LIMIT 1");
    } catch (\Throwable $e) {
        $pdo->exec("ALTER TABLE `jetmax_traffic`
            ADD COLUMN `country_code` char(2) DEFAULT NULL AFTER `referrer`,
            ADD COLUMN `country_name` varchar(128) DEFAULT NULL AFTER `country_code`");
    }

    try {
        $pdo->query("SELECT 1 FROM `jetmax_ip_cache` LIMIT 1");
    } catch (\Throwable $e) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS `jetmax_ip_cache` (
            `ip_address` varchar(64) NOT NULL PRIMARY KEY,
            `country_code` char(2) DEFAULT NULL,
            `country_name` varchar(128) DEFAULT NULL,
            `updated_at` datetime NOT NULL DEFAULT current_timestamp()
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }

    // Migration: ip_hash → ip_address in ip_cache
    try {
        $pdo->query("SELECT `ip_hash` FROM `jetmax_ip_cache` LIMIT 1");
        $pdo->exec("ALTER TABLE `jetmax_ip_cache` CHANGE COLUMN `ip_hash` `ip_address` VARCHAR(64) NOT NULL");
    } catch (\Throwable $e) {
        // already migrated
    }

    // Migration: search_query
    try {
        $pdo->query("SELECT `search_query` FROM `jetmax_traffic` LIMIT 1");
    } catch (\Throwable $e) {
        $pdo->exec("ALTER TABLE `jetmax_traffic`
            ADD COLUMN `search_query` varchar(255) DEFAULT NULL AFTER `referrer`");
    }

    // Migration: is_404
    try {
        $pdo->query("SELECT `is_404` FROM `jetmax_traffic` LIMIT 1");
    } catch (\Throwable $e) {
        $pdo->exec("ALTER TABLE `jetmax_traffic`
            ADD COLUMN `is_404` tinyint(1) NOT NULL DEFAULT 0 AFTER `post_type`");
    }
}

add_action('init', function () {
    if (php_sapi_name() === 'cli') return;

    $pdo = $GLOBALS['pdo'] ?? null;
    if (!$pdo) return;

    jetmax_ensure_schema();

    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    $urlPath = parse_url($uri, PHP_URL_PATH) ?? '/';

    if (preg_match('#\.(css|js|png|jpg|jpeg|gif|ico|svg|woff2?|ttf|eot|map|json)$#i', $urlPath)) return;

    $adminPrefix = function_exists('get_admin_path') ? get_admin_path($pdo) : '/adiwira';
    if (strpos($urlPath, $adminPrefix) === 0) return;

    if (function_exists('auth_path_matches')) {
        $lp = get_login_path($pdo);
        $rp = get_register_path($pdo);
        if (auth_path_matches($lp)) return;
        if (auth_path_matches($rp)) return;
    }

    // Prefer Cloudflare / X-Forwarded-For headers
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    if (($pos = strpos($ip, ',')) !== false) $ip = substr($ip, 0, $pos);
    $ip = trim($ip);
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) $ip = '0.0.0.0';

    $ua = substr(($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 500);
    $referrer = substr(($_SERVER['HTTP_REFERER'] ?? ''), 0, 2048);

    $searchQuery = null;
    if (!empty($_GET['s'])) {
        $searchQuery = mb_substr(trim((string)$_GET['s']), 0, 255);
    }

    $countryCode = null;
    $countryName = null;
    $cacheStmt = $pdo->prepare("SELECT `country_code`, `country_name` FROM `jetmax_ip_cache` WHERE `ip_address` = ?");
    $cacheStmt->execute([$ip]);
    $cached = $cacheStmt->fetch(PDO::FETCH_ASSOC);

    if ($cached) {
        $countryCode = $cached['country_code'];
        $countryName = $cached['country_name'];
    } elseif ($ip !== '0.0.0.0' && filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
        $geo = @json_decode(@file_get_contents('http://ip-api.com/json/' . $ip . '?fields=status,countryCode,country'), true);
        if ($geo && ($geo['status'] ?? '') === 'success') {
            $countryCode = $geo['countryCode'] ?? null;
            $countryName = $geo['country'] ?? null;
            $upsert = $pdo->prepare("INSERT INTO `jetmax_ip_cache` (`ip_address`, `country_code`, `country_name`) VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE `country_code` = VALUES(`country_code`), `country_name` = VALUES(`country_name`), `updated_at` = NOW()");
            $upsert->execute([$ip, $countryCode, $countryName]);
        }
    } elseif (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
        $countryCode = '--';
        $countryName = 'Local/Private';
    }

    $stmt = $pdo->prepare("INSERT INTO `jetmax_traffic` (`url`, `ip_address`, `user_agent`, `referrer`, `search_query`, `country_code`, `country_name`)
        VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$urlPath, $ip, $ua, $referrer, $searchQuery, $countryCode, $countryName]);
    $visitId = (int)$pdo->lastInsertId();
    $GLOBALS['jetmax_visit_id'] = $visitId;

    register_shutdown_function(function () use ($pdo, $visitId) {
        if (http_response_code() >= 400) {
            try {
                $st = $pdo->prepare("UPDATE `jetmax_traffic` SET `is_404` = 1 WHERE `id` = ?");
                $st->execute([$visitId]);
            } catch (\Throwable $e) {
            }
        }
    });
});

add_action('admin_init', function () {
    $pdo = $GLOBALS['pdo'] ?? null;
    if ($pdo) jetmax_ensure_schema();
});

add_filter('post_content', function ($html, $post) {
    $visitId = $GLOBALS['jetmax_visit_id'] ?? null;
    if ($visitId && !empty($post['id'])) {
        $pdo = $GLOBALS['pdo'] ?? null;
        if ($pdo) {
            $stmt = $pdo->prepare("UPDATE `jetmax_traffic` SET `post_id` = ?, `post_type` = ? WHERE `id` = ?");
            $stmt->execute([(int)$post['id'], $post['type'] ?? 'article', $visitId]);
        }
    }
    return $html;
}, 99, 2);

// ─── Dashboard home widget ───
add_filter('dashboard_widgets', function (array $widgets): array {
    $pdo = $GLOBALS['pdo'] ?? null;
    if (!$pdo) return $widgets;
    $enabled = settings_get($pdo, 'jetmax_dash_widget_enabled', '0');
    if ($enabled === '1') {
        $widgets['jetmax_traffic'] = [
            'title'       => 'Traffic',
            'render'      => 'jetmax_dash_widget_traffic',
    
        ];
    }
    return $widgets;
});

function jetmax_dash_widget_traffic(PDO $pdo): string
{
    try {
        $today = $pdo->query("SELECT COUNT(*) AS v, COUNT(DISTINCT `ip_address`) AS u FROM `jetmax_traffic` WHERE DATE(`visited_at`) = CURDATE()")->fetch(PDO::FETCH_ASSOC);
        $week  = $pdo->query("SELECT COUNT(*) AS v, COUNT(DISTINCT `ip_address`) AS u FROM `jetmax_traffic` WHERE `visited_at` >= NOW() - INTERVAL 7 DAY")->fetch(PDO::FETCH_ASSOC);
        $err   = $pdo->query("SELECT COUNT(*) AS c FROM `jetmax_traffic` WHERE `is_404` = 1 AND `visited_at` >= NOW() - INTERVAL 7 DAY")->fetchColumn();
        $srch  = $pdo->query("SELECT COUNT(DISTINCT `search_query`) AS c FROM `jetmax_traffic` WHERE `search_query` IS NOT NULL AND `search_query` != '' AND `visited_at` >= NOW() - INTERVAL 7 DAY")->fetchColumn();
        $cats  = $pdo->query("
            SELECT c.name, c.slug, COUNT(*) AS visits
            FROM `jetmax_traffic` t
            JOIN `post_categories` pc ON pc.post_id = t.post_id
            JOIN `categories` c ON c.id = pc.category_id
            WHERE t.visited_at >= NOW() - INTERVAL 7 DAY
              AND t.post_id IS NOT NULL
            GROUP BY c.id
            ORDER BY visits DESC
            LIMIT 5
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch (\Throwable $e) {
        return '';
    }

    $tv = (int)$today['v'];
    $tu = (int)$today['u'];
    $wv = (int)$week['v'];
    $wu = (int)$week['u'];

    $catRows = '';
    if ($cats) {
        $idx = 0;
        foreach ($cats as $cat) {
            $idx++;
            $name = h($cat['name'] ?? '?');
            $slug = h($cat['slug'] ?? '');
            $visits = (int)($cat['visits'] ?? 0);
            $catRows .= '<tr>'
                     . '<td style="width:1.8em;font-weight:600;color:var(--adam-muted)">' . $idx . '</td>'
                     . '<td><a href="/category/' . $slug . '/" class="dw-link">' . $name . '</a></td>'
                     . '<td style="text-align:right;white-space:nowrap;color:var(--adam-muted);font-size:11px">' . $visits . '</td></tr>';
        }
    }

    return '
<div class="dw-card">
  <div class="dw-card-head">
    <span class="dw-card-icon">' . svg_ico('activity') . '</span>
    <span class="dw-card-title">Traffic</span>
  </div>
  <div class="dw-card-body">
    <div class="dw-stats" style="grid-template-columns:repeat(4,1fr)">
      <div class="dw-stat">
        <span class="dw-stat-num">' . $tv . '</span>
        <span class="dw-stat-label">Today Views</span>
      </div>
      <div class="dw-stat">
        <span class="dw-stat-num">' . $tu . '</span>
        <span class="dw-stat-label">Today Unique</span>
      </div>
      <div class="dw-stat">
        <span class="dw-stat-num">' . $wv . '</span>
        <span class="dw-stat-label">7d Views</span>
      </div>
      <div class="dw-stat">
        <span class="dw-stat-num">' . $wu . '</span>
        <span class="dw-stat-label">7d Unique</span>
      </div>
    </div>
    <div style="display:flex;gap:12px;margin-top:8px;font-size:11px;color:var(--adam-muted)">
      <span>404: ' . (int)$err . '</span>
      <span>Searches: ' . (int)$srch . '</span>
    </div>' . ($catRows ? '
    <details style="margin-top:12px;border-top:1px solid var(--adam-border,#e2e8f0);padding-top:8px" open>
      <summary style="cursor:pointer;font-weight:600;font-size:12px;color:var(--adam-muted,#64748b);margin-bottom:6px">Top Categories (7d)</summary>
      <table style="width:100%;border-collapse:collapse;font-size:12px">
        <tbody>' . $catRows . '</tbody>
      </table>
    </details>' : '') . '
  </div>
</div>';
}

// ─── Public sidebar widget ───
add_action('wp_head', function () {
    $pdo = $GLOBALS['pdo'] ?? null;
    if (!$pdo) return;
    if (settings_get($pdo, 'jetmax_sidebar_widget_enabled', '0') !== '1') return;
    echo '<style>.w-stats-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}.w-stats-item{background:var(--surface-hover,var(--bg-soft,#f1f5f9));padding:12px;border-radius:8px;text-align:center}.w-stats-num{font-size:1.4rem;font-weight:700;color:var(--text);line-height:1.3}.w-stats-label{font-size:.75rem;color:var(--muted);margin-top:2px}</style>';
});

add_filter('sidebar_widget_types', function (array $types): array {
    $pdo = $GLOBALS['pdo'] ?? null;
    if (!$pdo) return $types;
    $enabled = settings_get($pdo, 'jetmax_sidebar_widget_enabled', '0');
    if ($enabled === '1') {
        $types['jetmax_traffic_public'] = [
            'label'          => 'Traffic (Public)',
            'desc'           => 'Show traffic stats on frontend sidebar.',
            'default_config' => ['title' => 'Traffic'],
        ];
    }
    return $types;
}, 20);

add_filter('render_sidebar_widget', function ($html, string $type, array $config, PDO $pdo) {
    if ($type !== 'jetmax_traffic_public') return $html;
    return jetmax_sidebar_widget_traffic($pdo, $config);
}, 10, 4);

function jetmax_sidebar_widget_traffic(PDO $pdo, array $config): string
{
    try {
        $day  = $pdo->query("SELECT COUNT(DISTINCT `ip_address`) AS u FROM `jetmax_traffic` WHERE DATE(`visited_at`) = CURDATE()")->fetchColumn();
        $week = $pdo->query("SELECT COUNT(DISTINCT `ip_address`) AS u FROM `jetmax_traffic` WHERE `visited_at` >= NOW() - INTERVAL 7 DAY")->fetchColumn();
        $mon  = $pdo->query("SELECT COUNT(DISTINCT `ip_address`) AS u FROM `jetmax_traffic` WHERE `visited_at` >= NOW() - INTERVAL 1 MONTH")->fetchColumn();
        $year = $pdo->query("SELECT COUNT(DISTINCT `ip_address`) AS u FROM `jetmax_traffic` WHERE `visited_at` >= NOW() - INTERVAL 1 YEAR")->fetchColumn();
    } catch (\Throwable $e) {
        return '';
    }
    $title = h($config['title'] ?? 'Traffic');
    $items = [
        ['num' => (int)$day,  'label' => 'Today'],
        ['num' => (int)$week, 'label' => 'Week'],
        ['num' => (int)$mon,  'label' => 'Month'],
        ['num' => (int)$year, 'label' => 'Year'],
    ];
    $grid = '';
    foreach ($items as $it) {
        $grid .= '<div class="w-stats-item">'
               . '<div class="w-stats-num">' . $it['num'] . '</div>'
               . '<div class="w-stats-label">' . $it['label'] . '</div>'
               . '</div>';
    }
    return '<div class="w-box w-jetmax-stats">'
         . '<h3 class="w-title">' . $title . '</h3>'
         . '<div class="w-stats-grid">' . $grid . '</div>'
         . '</div>';
}

// ─── Uninstall: data cleanup when user chooses "Delete all data" ───
add_action('plugin_uninstall', function (string $name) {
    if ($name !== 'jetmax') return;
    $pdo = $GLOBALS['pdo'] ?? null;
    if (!$pdo) return;
    try {
        $pdo->exec("DROP TABLE IF EXISTS `jetmax_traffic`");
        $pdo->exec("DROP TABLE IF EXISTS `jetmax_ip_cache`");
        $pdo->exec("DELETE FROM `settings` WHERE `key` LIKE 'jetmax_%'");
    } catch (\Throwable $e) {}
});
