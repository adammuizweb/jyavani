<?php
declare(strict_types=1);

function jetmax_ensure_schema(): void {
    $pdo = $GLOBALS['pdo'] ?? null;
    if (!$pdo) return;

    try {
        $pdo->query("SELECT 1 FROM `jetmax_traffic` LIMIT 1");
    } catch (\Throwable $e) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS `jetmax_traffic` (
            `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            `post_id` bigint(20) unsigned DEFAULT NULL,
            `post_type` varchar(20) DEFAULT NULL,
            `url` varchar(2048) NOT NULL DEFAULT '',
            `ip_hash` varchar(64) NOT NULL DEFAULT '',
            `user_agent` text DEFAULT NULL,
            `referrer` text DEFAULT NULL,
            `country_code` char(2) DEFAULT NULL,
            `country_name` varchar(128) DEFAULT NULL,
            `visited_at` datetime NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (`id`),
            KEY `visited_at` (`visited_at`),
            KEY `post_id` (`post_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }

    try {
        $pdo->query("SELECT `country_code` FROM `jetmax_traffic` LIMIT 1");
    } catch (\Throwable $e) {
        $pdo->exec("ALTER TABLE `jetmax_traffic`
            ADD COLUMN `country_code` char(2) DEFAULT NULL AFTER `referrer`,
            ADD COLUMN `country_name` varchar(128) DEFAULT NULL AFTER `country_code`");
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS `jetmax_ip_cache` (
        `ip_hash` varchar(64) NOT NULL PRIMARY KEY,
        `country_code` char(2) DEFAULT NULL,
        `country_name` varchar(128) DEFAULT NULL,
        `updated_at` datetime NOT NULL DEFAULT current_timestamp()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

add_action('init', function () {
    if (php_sapi_name() === 'cli') return;

    $pdo = $GLOBALS['pdo'] ?? null;
    if (!$pdo) return;

    jetmax_ensure_schema();

    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    $urlPath = parse_url($uri, PHP_URL_PATH) ?? '/';

    if (preg_match('#\.(css|js|png|jpg|jpeg|gif|ico|svg|woff2?|ttf|eot|map|json)$#i', $urlPath)) return;

    $adminPrefix = function_exists('get_admin_path') ? get_admin_path($pdo) : '/adiwira';
    if (strpos($urlPath, $adminPrefix) === 0) return;

    if (function_exists('auth_path_matches')) {
        $lp = get_login_path($pdo);
        $rp = get_register_path($pdo);
        if (auth_path_matches($lp)) return;
        if (auth_path_matches($rp)) return;
    }

    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $ipHash = hash('sha256', $ip);
    $ua = substr(($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 500);
    $referrer = substr(($_SERVER['HTTP_REFERER'] ?? ''), 0, 2048);

    $countryCode = null;
    $countryName = null;
    $cacheStmt = $pdo->prepare("SELECT `country_code`, `country_name` FROM `jetmax_ip_cache` WHERE `ip_hash` = ?");
    $cacheStmt->execute([$ipHash]);
    $cached = $cacheStmt->fetch(PDO::FETCH_ASSOC);

    if ($cached) {
        $countryCode = $cached['country_code'];
        $countryName = $cached['country_name'];
    } elseif (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
        $geo = @json_decode(@file_get_contents('http://ip-api.com/json/' . $ip . '?fields=status,countryCode,country'), true);
        if ($geo && ($geo['status'] ?? '') === 'success') {
            $countryCode = $geo['countryCode'] ?? null;
            $countryName = $geo['country'] ?? null;
            $upsert = $pdo->prepare("INSERT INTO `jetmax_ip_cache` (`ip_hash`, `country_code`, `country_name`) VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE `country_code` = VALUES(`country_code`), `country_name` = VALUES(`country_name`), `updated_at` = NOW()");
            $upsert->execute([$ipHash, $countryCode, $countryName]);
        }
    }

    $stmt = $pdo->prepare("INSERT INTO `jetmax_traffic` (`url`, `ip_hash`, `user_agent`, `referrer`, `country_code`, `country_name`)
        VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$urlPath, $ipHash, $ua, $referrer, $countryCode, $countryName]);
    $GLOBALS['jetmax_visit_id'] = (int)$pdo->lastInsertId();
});

add_action('admin_init', function () {
    $pdo = $GLOBALS['pdo'] ?? null;
    if ($pdo) jetmax_ensure_schema();
});

add_filter('post_content', function ($html, $post) {
    $visitId = $GLOBALS['jetmax_visit_id'] ?? null;
    if ($visitId && !empty($post['id'])) {
        $pdo = $GLOBALS['pdo'] ?? null;
        if ($pdo) {
            $stmt = $pdo->prepare("UPDATE `jetmax_traffic` SET `post_id` = ?, `post_type` = ? WHERE `id` = ?");
            $stmt->execute([(int)$post['id'], $post['type'] ?? 'article', $visitId]);
        }
    }
    return $html;
}, 99, 2);
