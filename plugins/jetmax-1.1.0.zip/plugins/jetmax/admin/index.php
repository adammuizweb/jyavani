<?php
declare(strict_types=1);

if (!defined('DASHBOARD_CONTEXT')) exit;

$pdo = $GLOBALS['pdo'];

// Auto-create tables if missing (safety net for sites without init hook support)
try {
    $pdo->query("SELECT 1 FROM `jetmax_traffic` LIMIT 1");
} catch (\Throwable $e) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `jetmax_traffic` (
        `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        `post_id` bigint(20) unsigned DEFAULT NULL,
        `post_type` varchar(20) DEFAULT NULL,
        `url` varchar(2048) NOT NULL DEFAULT '',
        `ip_hash` varchar(64) NOT NULL DEFAULT '',
        `user_agent` text DEFAULT NULL,
        `referrer` text DEFAULT NULL,
        `country_code` char(2) DEFAULT NULL,
        `country_name` varchar(128) DEFAULT NULL,
        `visited_at` datetime NOT NULL DEFAULT current_timestamp(),
        PRIMARY KEY (`id`),
        KEY `visited_at` (`visited_at`),
        KEY `post_id` (`post_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS `jetmax_ip_cache` (
        `ip_hash` varchar(64) NOT NULL PRIMARY KEY,
        `country_code` char(2) DEFAULT NULL,
        `country_name` varchar(128) DEFAULT NULL,
        `updated_at` datetime NOT NULL DEFAULT current_timestamp()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

// Verify table was created
try {
    $pdo->query("SELECT 1 FROM `jetmax_traffic` LIMIT 1");
} catch (\Throwable $e) {
    echo '<div class="alert alert-warning" style="background:var(--adam-surface-3);color:var(--adam-text);padding:16px;border-radius:var(--adam-radius)">Failed to create <code>jetmax_traffic</code> table. Check database permissions.</div>';
    return;
}

$base = defined('ADMIN_BASE_PATH') ? ADMIN_BASE_PATH : '/adiwira';

// ——— Date range ———
$range = $_GET['range'] ?? '7d';
$ranges = [
    '24h'  => ['label' => '24 Hours', 'sql' => 'INTERVAL 24 HOUR'],
    '7d'   => ['label' => '7 Days',   'sql' => 'INTERVAL 7 DAY'],
    '30d'  => ['label' => '30 Days',  'sql' => 'INTERVAL 30 DAY'],
    '3m'   => ['label' => '3 Months', 'sql' => 'INTERVAL 3 MONTH'],
    '6m'   => ['label' => '6 Months', 'sql' => 'INTERVAL 6 MONTH'],
    '1y'   => ['label' => '1 Year',   'sql' => 'INTERVAL 1 YEAR'],
    'all'  => ['label' => 'All Time', 'sql' => 'INTERVAL 100 YEAR'],
];
if (!isset($ranges[$range])) $range = '7d';
$intervalSql = $ranges[$range]['sql'];

// Group expression for chart
$chartGroup = ($range === '24h') ? "DATE_FORMAT(`visited_at`, '%Y-%m-%d %H:00')" : "DATE(`visited_at`)";
$chartLabel = ($range === '24h') ? 'Hour' : 'Date';

// ——— Summary ———
$summary = $pdo->prepare("SELECT
    COUNT(*) AS total,
    COUNT(DISTINCT `ip_hash`) AS unique_visitors,
    SUM(CASE WHEN DATE(`visited_at`) = CURDATE() THEN 1 ELSE 0 END) AS today,
    SUM(CASE WHEN `post_id` IS NOT NULL THEN 1 ELSE 0 END) AS post_views
FROM `jetmax_traffic` WHERE `visited_at` >= NOW() - $intervalSql");
$summary->execute();
$s = $summary->fetch(PDO::FETCH_ASSOC);

// ——— Chart data ———
$chart = $pdo->prepare("SELECT $chartGroup AS period, COUNT(*) AS hits, COUNT(DISTINCT `ip_hash`) AS uniques
    FROM `jetmax_traffic` WHERE `visited_at` >= NOW() - $intervalSql GROUP BY period ORDER BY period ASC");
$chart->execute();
$chartRows = $chart->fetchAll(PDO::FETCH_ASSOC);

$chartLabels = [];
$chartHits = [];
$chartUniques = [];
$maxHits = 1;
foreach ($chartRows as $r) {
    $chartLabels[] = $r['period'];
    $chartHits[] = (int)$r['hits'];
    $chartUniques[] = (int)$r['uniques'];
    if ((int)$r['hits'] > $maxHits) $maxHits = (int)$r['hits'];
}

// ——— Top pages ———
$topPages = $pdo->prepare("SELECT `url`, COUNT(*) AS hits FROM `jetmax_traffic`
    WHERE `visited_at` >= NOW() - $intervalSql GROUP BY `url` ORDER BY hits DESC LIMIT 10");
$topPages->execute();
$topPagesRows = $topPages->fetchAll(PDO::FETCH_ASSOC);

// ——— Top posts ———
$topPosts = $pdo->prepare("SELECT t.`post_id`, p.`title`, p.`slug`, p.`type`, COUNT(*) AS hits
    FROM `jetmax_traffic` t LEFT JOIN `posts` p ON t.`post_id` = p.`id`
    WHERE t.`post_id` IS NOT NULL AND t.`visited_at` >= NOW() - $intervalSql
    GROUP BY t.`post_id` ORDER BY hits DESC LIMIT 10");
$topPosts->execute();
$topPostsRows = $topPosts->fetchAll(PDO::FETCH_ASSOC);

// ——— Top referrers ———
$topRefs = $pdo->prepare("SELECT `referrer`, COUNT(*) AS hits FROM `jetmax_traffic`
    WHERE `referrer` != '' AND `visited_at` >= NOW() - $intervalSql
    GROUP BY `referrer` ORDER BY hits DESC LIMIT 10");
$topRefs->execute();
$topRefsRows = $topRefs->fetchAll(PDO::FETCH_ASSOC);

// ——— Country breakdown ———
$countries = $pdo->prepare("SELECT `country_code`, `country_name`, COUNT(*) AS hits,
    COUNT(DISTINCT `ip_hash`) AS uniques
    FROM `jetmax_traffic` WHERE `country_code` IS NOT NULL AND `visited_at` >= NOW() - $intervalSql
    GROUP BY `country_code` ORDER BY hits DESC LIMIT 15");
$countries->execute();
$countryRows = $countries->fetchAll(PDO::FETCH_ASSOC);

// ——— Recent visits ———
$recent = $pdo->prepare("SELECT `url`, `ip_hash`, `user_agent`, `country_code`, `visited_at`, `post_id`
    FROM `jetmax_traffic` WHERE `visited_at` >= NOW() - $intervalSql ORDER BY `visited_at` DESC LIMIT 25");
$recent->execute();
$recentRows = $recent->fetchAll(PDO::FETCH_ASSOC);
?>
<style>
.jm-chart-wrap { overflow-x:auto; padding-top:8px }
.jm-chart { display:flex; align-items:flex-end; gap:3px; height:160px; min-width:100% }
.jm-bar-wrap { flex:1; display:flex; flex-direction:column; align-items:center; height:100%; justify-content:flex-end; position:relative }
.jm-bar { width:100%; min-width:4px; border-radius:3px 3px 0 0; transition:opacity .2s; cursor:pointer; background:var(--adam-primary) }
.jm-bar:hover { opacity:.7 }
.jm-bar.unique { background:var(--adam-muted); height:0 }
.jm-bar-label { font-size:9px; color:var(--adam-muted); margin-top:4px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:50px; text-align:center }
.jm-range-form { display:flex; gap:6px; flex-wrap:wrap; margin-bottom:20px }
.jm-range-btn { padding:6px 14px; border-radius:6px; border:1px solid var(--adam-border); background:var(--adam-card); color:var(--adam-text); font-size:12px; cursor:pointer; text-decoration:none; transition:all .15s }
.jm-range-btn:hover { border-color:var(--adam-primary); color:var(--adam-primary) }
.jm-range-btn.active { background:var(--adam-primary); color:#fff; border-color:var(--adam-primary) }
.jm-grid2 { display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:16px }
.jm-grid3 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px; margin-bottom:16px }
.jm-card { background:var(--adam-card); border:1px solid var(--adam-border); border-radius:var(--adam-radius-lg); padding:20px; box-shadow:var(--adam-shadow) }
.jm-card h3 { margin:0 0 12px; font-size:11px; text-transform:uppercase; letter-spacing:.6px; opacity:.6; color:var(--adam-text) }
.jm-stat { display:flex; gap:16px; flex-wrap:wrap }
.jm-stat-item { flex:1; min-width:100px }
.jm-stat-item .num { font-size:28px; font-weight:700; color:var(--adam-text); margin:0; line-height:1.2 }
.jm-stat-item .lbl { font-size:11px; text-transform:uppercase; letter-spacing:.5px; opacity:.5; color:var(--adam-text); margin-top:2px }
.jm-table { width:100%; border-collapse:collapse }
.jm-table th { text-align:left; padding:8px 10px; font-size:11px; text-transform:uppercase; letter-spacing:.4px; opacity:.5; color:var(--adam-text); border-bottom:1px solid var(--adam-border); font-weight:600 }
.jm-table td { padding:8px 10px; border-bottom:1px solid var(--adam-border-soft); font-size:13px; color:var(--adam-text) }
.jm-table tr:hover td { background:var(--adam-hover) }
.jm-link { color:var(--adam-link); text-decoration:none }
.jm-link:hover { color:var(--adam-link-hover); text-decoration:underline }
.jm-flag { display:inline-block; width:20px; height:14px; vertical-align:middle; margin-right:6px; border-radius:2px }
.jm-badge { display:inline-block; padding:2px 8px; border-radius:4px; font-size:11px; font-weight:600; background:var(--adam-surface-3); color:var(--adam-text-2) }
</style>

<form method="get" class="jm-range-form" id="jm-range-form">
    <input type="hidden" name="page" value="admin/tools/jetmax">
    <?php foreach ($ranges as $k => $v): ?>
    <a href="?page=admin/tools/jetmax&range=<?= $k ?>" class="jm-range-btn <?= $range === $k ? 'active' : '' ?>"><?= $v['label'] ?></a>
    <?php endforeach; ?>
</form>

<div class="jm-grid3">
    <div class="jm-card">
        <h3>Page Views</h3>
        <div class="num" style="font-size:32px;font-weight:700;color:var(--adam-text)"><?= (int)$s['total'] ?></div>
        <div style="font-size:12px;color:var(--adam-muted);margin-top:2px"><?= (int)$s['today'] ?> today</div>
    </div>
    <div class="jm-card">
        <h3>Unique Visitors</h3>
        <div class="num" style="font-size:32px;font-weight:700;color:var(--adam-text)"><?= (int)$s['unique_visitors'] ?></div>
        <div style="font-size:12px;color:var(--adam-muted);margin-top:2px"><?= (int)$s['post_views'] ?> article views</div>
    </div>
    <div class="jm-card">
        <h3>Countries</h3>
        <div class="num" style="font-size:32px;font-weight:700;color:var(--adam-text)"><?= count($countryRows) ?></div>
        <div style="font-size:12px;color:var(--adam-muted);margin-top:2px">
            <?php foreach (array_slice($countryRows, 0, 3) as $c): ?>
                <span style="margin-right:8px"><?= e($c['country_name'] ?? $c['country_code']) ?> <strong><?= $c['hits'] ?></strong></span>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php if (!empty($chartRows)): ?>
<div class="jm-card" style="margin-bottom:16px">
    <h3>Traffic — <?= $ranges[$range]['label'] ?></h3>
    <div style="display:flex;gap:16px;font-size:11px;color:var(--adam-muted);margin-bottom:4px">
        <span><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:var(--adam-primary);vertical-align:middle;margin-right:4px"></span> Views</span>
        <span><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:var(--adam-muted);vertical-align:middle;margin-right:4px"></span> Unique</span>
    </div>
    <div class="jm-chart-wrap">
        <div class="jm-chart" style="height:160px">
            <?php foreach ($chartRows as $i => $r):
                $h = max(1, (int)$r['hits']);
                $u = max(1, (int)$r['uniques']);
                $hp = round(($h / $maxHits) * 100);
                $up = round(($u / $maxHits) * 100);
            ?>
            <div class="jm-bar-wrap" title="<?= e($r['period']) ?> — <?= $h ?> views, <?= $u ?> unique">
                <div class="jm-bar" style="height:<?= $hp ?>%;background:var(--adam-primary)"></div>
                <div class="jm-bar unique" style="height:<?= $up ?>%;background:var(--adam-muted);margin-top:-<?= $up ?>px;opacity:.5"></div>
                <div class="jm-bar-label"><?= $chartLabel === 'Hour' ? date('H:00', strtotime($r['period'])) : date('M j', strtotime($r['period'])) ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="jm-grid2">
    <div class="jm-card">
        <h3>Top Pages</h3>
        <?php if (empty($topPagesRows)): ?>
        <p style="opacity:.5;color:var(--adam-muted)">No data yet</p>
        <?php else: ?>
        <table class="jm-table">
            <tr><th>Page</th><th style="width:60px;text-align:right">Views</th></tr>
            <?php foreach ($topPagesRows as $r): ?>
            <tr>
                <td><a href="<?= e($r['url']) ?>" target="_blank" class="jm-link" style="max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:inline-block;vertical-align:middle"><?= e($r['url']) ?></a></td>
                <td style="text-align:right;font-weight:600"><?= $r['hits'] ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
    </div>
    <div class="jm-card">
        <h3>Top Articles</h3>
        <?php if (empty($topPostsRows)): ?>
        <p style="opacity:.5;color:var(--adam-muted)">No data yet</p>
        <?php else: ?>
        <table class="jm-table">
            <tr><th>Article</th><th style="width:60px;text-align:right">Views</th></tr>
            <?php foreach ($topPostsRows as $r): ?>
            <tr>
                <td style="max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                    <?php if ($r['slug']): ?>
                    <a href="/<?= e($r['slug']) ?>/" target="_blank" class="jm-link"><?= e($r['title'] ?: $r['slug']) ?></a>
                    <?php else: ?>
                    <span style="opacity:.5;color:var(--adam-muted)">post #<?= $r['post_id'] ?></span>
                    <?php endif; ?>
                </td>
                <td style="text-align:right;font-weight:600"><?= $r['hits'] ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
    </div>
</div>

<div class="jm-grid2">
    <div class="jm-card">
        <h3>Top Referrers</h3>
        <?php if (empty($topRefsRows)): ?>
        <p style="opacity:.5;color:var(--adam-muted)">No referrer data yet</p>
        <?php else: ?>
        <table class="jm-table">
            <tr><th>Source</th><th style="width:60px;text-align:right">Views</th></tr>
            <?php foreach ($topRefsRows as $r): ?>
            <tr>
                <td style="max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                    <?php if (str_starts_with($r['referrer'], 'http')): ?>
                    <a href="<?= e($r['referrer']) ?>" target="_blank" rel="noopener" class="jm-link"><?= e(parse_url($r['referrer'], PHP_URL_HOST) ?: $r['referrer']) ?></a>
                    <?php else: ?>
                    <span style="opacity:.5;color:var(--adam-muted)">direct / unknown</span>
                    <?php endif; ?>
                </td>
                <td style="text-align:right;font-weight:600"><?= $r['hits'] ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
    </div>
    <div class="jm-card">
        <h3>Countries</h3>
        <?php if (empty($countryRows)): ?>
        <p style="opacity:.5;color:var(--adam-muted)">No location data yet</p>
        <?php else: ?>
        <table class="jm-table">
            <tr><th>Country</th><th style="width:60px;text-align:right">Visits</th><th style="width:60px;text-align:right">Unique</th></tr>
            <?php foreach ($countryRows as $r): ?>
            <tr>
                <td>
                    <?php if ($r['country_code']): ?>
                    <span class="jm-flag" style="background:var(--adam-surface-3);text-align:center;line-height:14px;font-size:10px"><?= e($r['country_code']) ?></span>
                    <?php endif; ?>
                    <?= e($r['country_name'] ?? $r['country_code'] ?? 'Unknown') ?>
                </td>
                <td style="text-align:right;font-weight:600"><?= $r['hits'] ?></td>
                <td style="text-align:right;color:var(--adam-muted)"><?= $r['uniques'] ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
    </div>
</div>

<div class="jm-card" style="margin-bottom:16px">
    <h3>Recent Visits</h3>
    <?php if (empty($recentRows)): ?>
    <p style="opacity:.5;color:var(--adam-muted)">No visits yet</p>
    <?php else: ?>
    <div style="max-height:400px;overflow-y:auto">
    <table class="jm-table">
        <tr><th>Page</th><th style="width:70px">Country</th><th style="width:130px">Time</th></tr>
        <?php foreach ($recentRows as $r): ?>
        <tr>
            <td style="max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                <a href="<?= e($r['url']) ?>" target="_blank" class="jm-link"><?= e($r['url']) ?></a>
            </td>
            <td>
                <?php if ($r['country_code']): ?>
                <span class="jm-badge"><?= e($r['country_code']) ?></span>
                <?php else: ?>
                <span style="opacity:.3">—</span>
                <?php endif; ?>
            </td>
            <td style="white-space:nowrap;color:var(--adam-muted);font-size:12px"><?= date('M j, H:i', strtotime($r['visited_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    </div>
    <?php endif; ?>
</div>

<p style="opacity:.3;font-size:11px;color:var(--adam-muted)">JetMax v1.1.0 — IP di-hash SHA-256. Geolokasi via ip-api.com (free tier).</p>
